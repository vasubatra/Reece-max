//
//  DataViewController.swift
//  SIT374_v0.01
//
//  Created by ALUSH SELIMI on 12/4/18.
//  Copyright © 2018 ALUSH SELIMI. All rights reserved.
//

import UIKit
import MapKit

class DataViewController: UIViewController {

    @IBOutlet weak var dataLabel: UILabel!
    var dataObject: String = ""


    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.dataLabel!.text = dataObject
    }

   
    
    @IBOutlet var mapView: MKMapView!
    
    
    
    @IBAction func talkButton(_ sender: Any) {
    }
    
    
}

