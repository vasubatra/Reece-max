//
//  DataViewController.swift
//  SIT374_v0.01
//
//  Created by ALUSH SELIMI on 12/4/18.
//  Copyright © 2018 ALUSH SELIMI. All rights reserved.
//

// https://www.appcoda.com/siri-speech-framework/

import UIKit
import MapKit
import Speech

class DataViewController: UIViewController, SFSpeechRecognizerDelegate {

    @IBOutlet weak var dataLabel: UILabel!
    var dataObject: String = ""
    @IBOutlet weak var textField: UITextView!
    
    
    @IBOutlet weak var talksButton: UIButton!
    @IBAction func talkButton(_ sender: AnyObject) {
        if audioEngine.isRunning {
            audioEngine.stop()
            recogntionRequest?.endAudio()
            talksButton.isEnabled = false
            talksButton.setTitle("Start Recording", for: .normal)
        } else {
            startRecording()
            talksButton.setTitle("Stop Recording", for: .normal)
        }
    }
    
    private let speechRecognizer = SFSpeechRecognizer(locale: Locale.init(identifier: "en-AU"))
    private var recogntionRequest: SFSpeechAudioBufferRecognitionRequest?
    private var recognitionTask: SFSpeechRecognitionTask?
    private let audioEngine = AVAudioEngine()
    
    func startRecording() {
        if recognitionTask != nil {
            recognitionTask?.cancel()
            recognitionTask = nil
        }
        
        let audioSession = AVAudioSession.sharedInstance()
        do {
            try audioSession.setCategory(AVAudioSessionCategoryRecord)
            try audioSession.setMode(AVAudioSessionModeMeasurement)
            try audioSession.setActive(true, with: .notifyOthersOnDeactivation)
        } catch
        {
            print("Session properties weren't set because of an error")
        }
        
        recogntionRequest = SFSpeechAudioBufferRecognitionRequest()
        
       let inputNode = audioEngine.inputNode
            fatalError("Audio Engine has no input node")
        
        
        guard let recognitionRequest = recogntionRequest else {
            fatalError("unable to create SFSpeechAudioBufferRecognitionRequest")
        }
        
        recogntionRequest?.shouldReportPartialResults = true
        
        recognitionTask = speechRecognizer!.recognitionTask(with: recogntionRequest!, resultHandler: { (result, error) in
            var isFinal = false
            if result != nil {
                self.textField.text = result?.bestTranscription.formattedString
                isFinal = (result?.isFinal)!
            }
            
            if error != nil || isFinal {
                self.audioEngine.stop()
                inputNode.removeTap(onBus: 0)
                
                self.recogntionRequest = nil
                self.recognitionTask = nil
                
                self.talksButton.isEnabled  = true
            }
        })
        
        let recordingFormat = inputNode.outputFormat(forBus: 0)
        inputNode.installTap(onBus: 0, bufferSize: 1024, format: recordingFormat) { (buffer, when) in
            self.recogntionRequest?.append(buffer)
        }
        
        audioEngine.prepare()
        
        do {
            try audioEngine.start()
        } catch {
            print("Audio Engine cant start")
        }
    }
    
    func speechRecognizer(_ speechRecognizer: SFSpeechRecognizer, availabilityDidChange available: Bool) {
        if available {
            talksButton.isEnabled = true
        } else {
            talksButton.isEnabled = false
        }
    }
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        talksButton.isEnabled = false
        speechRecognizer?.delegate = self
        
        SFSpeechRecognizer.requestAuthorization { (authStatus) in
            
            var isButtonEnabled = false
            
            switch authStatus {
            case .authorized:
                isButtonEnabled = true
            
            case .denied:
                isButtonEnabled = false
                print("Access Denied")
                
            case .restricted:
                isButtonEnabled = false
                print("Restricted")
            
            case .notDetermined:
                isButtonEnabled = false
                print("not yet authorized")
            }
            
            OperationQueue.main.addOperation() {
                self.talksButton.isEnabled = isButtonEnabled
            }
            
        }
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.dataLabel!.text = dataObject
    }

  
    
    @IBOutlet var mapView: MKMapView!
    
    
    
    
    
    
}

