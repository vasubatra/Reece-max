//
//  ViewController.swift
//  Reece Max Voice App
//  Team 25: Alush Selimi, Abdulrahman Baali, Hong Wey, Vasu Batra, Weiqi Zhang & Xueting Jiang
//
//
//  Created by Alush Selimi on 18/6/18.
//  Copyright © 2018 deakin. All rights reserved.
//

// import libraries
import UIKit
import MapKit
import CoreLocation
import Speech
import CoreML
import Foundation
import AVFoundation

// code for language classifier: search through strings as well as split and match them
public class re {
    public static func compile(_ pattern: String, flags: RegexObject.Flag = []) -> RegexObject  {
        return RegexObject(pattern: pattern, flags: flags)
    }
    
    public static func search(_ pattern: String, _ string: String, flags: RegexObject.Flag = []) -> MatchObject? {
        return re.compile(pattern, flags: flags).search(string)
    }
    
    public static func match(_ pattern: String, _ string: String, flags: RegexObject.Flag = []) -> MatchObject? {
        return re.compile(pattern, flags: flags).match(string)
    }
    
    public static func split(_ pattern: String, _ string: String, _ maxsplit: Int = 0, flags: RegexObject.Flag = []) -> [String?] {
        return re.compile(pattern, flags: flags).split(string, maxsplit)
    }
    
    public static func findall(_ pattern: String, _ string: String, flags: RegexObject.Flag = []) -> [String] {
        return re.compile(pattern, flags: flags).findall(string)
    }
    
    public static func finditer(_ pattern: String, _ string: String, flags: RegexObject.Flag = []) -> [MatchObject] {
        return re.compile(pattern, flags: flags).finditer(string)
    }
    
    public static func sub(_ pattern: String, _ repl: String, _ string: String, _ count: Int = 0, flags: RegexObject.Flag = []) -> String {
        return re.compile(pattern, flags: flags).sub(repl, string, count)
    }
    
    public static func subn(_ pattern: String, _ repl: String, _ string: String, _ count: Int = 0, flags: RegexObject.Flag = []) -> (String, Int) {
        return re.compile(pattern, flags: flags).subn(repl, string, count)
    }
    
    public class RegexObject {
        /// Typealias for NSRegularExpressionOptions
        public typealias Flag = NSRegularExpression.Options
        
        /// Whether this object is valid or not
        public var isValid: Bool {
            return regex != nil
        }
        
        /// Pattern used to construct this RegexObject
        public let pattern: String
        
        private let regex: NSRegularExpression?
        
        /// Underlying NSRegularExpression Object
        public var nsRegex: NSRegularExpression? {
            return regex
        }
        
        /// NSRegularExpressionOptions used to contructor this RegexObject
        public var flags: Flag {
            return regex?.options ?? []
        }
        
        /// Number of capturing groups
        public var groups: Int {
            return regex?.numberOfCaptureGroups ?? 0
        }
        
        public required init(pattern: String, flags: Flag = [])  {
            self.pattern = pattern
            do {
                self.regex = try NSRegularExpression(pattern: pattern, options: flags)
            } catch let error as NSError {
                self.regex = nil
                debugPrint(error)
            }
        }
        // function to search through the strings and match according to regular expression
        public func search(_ string: String, _ pos: Int = 0, _ endpos: Int? = nil, options: NSRegularExpression.MatchingOptions = []) -> MatchObject? {
            guard let regex = regex else {
                return nil
            }
            let start = pos > 0 ?pos :0
            let end = endpos ?? string.utf16.count
            let length = max(0, end - start)
            let range = NSRange(location: start, length: length)
            if let match = regex.firstMatch(in: string, options: options, range: range) {
                return MatchObject(string: string, match: match)
            }
            return nil
        }
        // function to match strings
        public func match(_ string: String, _ pos: Int = 0, _ endpos: Int? = nil) -> MatchObject? {
            return search(string, pos, endpos, options: [.anchored])
        }
        
        // function to split strings
        public func split(_ string: String, _ maxsplit: Int = 0) -> [String?] {
            guard let regex = regex else {
                return []
            }
            var splitsLeft = maxsplit == 0 ? Int.max : (maxsplit < 0 ? 0 : maxsplit)
            let range = NSRange(location: 0, length: string.utf16.count)
            var results = [String?]()
            var start = string.startIndex
            var end = string.startIndex
            regex.enumerateMatches(in: string, options: [], range: range) { result, _, stop in
                if splitsLeft <= 0 {
                    stop.pointee = true
                    return
                }
                
                guard let result = result, result.range.length > 0 else {
                    return
                }
                
                end = string.characters.index(string.startIndex, offsetBy: result.range.location)
                results.append(String(string[start..<end]))
                if regex.numberOfCaptureGroups > 0 {
                    results += MatchObject(string: string, match: result).groups()
                }
                splitsLeft -= 1
                start = string.index(end, offsetBy: result.range.length)
            }
            if start <= string.endIndex {
                results.append(String(string[start..<string.endIndex]))
            }
            return results
        }
        
        // function to find all matches
        public func findall(_ string: String, _ pos: Int = 0, _ endpos: Int? = nil) -> [String] {
            return finditer(string, pos, endpos).map { $0.group()! }
        }
        
        // function to find iterations
        public func finditer(_ string: String, _ pos: Int = 0, _ endpos: Int? = nil) -> [MatchObject] {
            guard let regex = regex else {
                return []
            }
            let start = pos > 0 ?pos :0
            let end = endpos ?? string.utf16.count
            let length = max(0, end - start)
            let range = NSRange(location: start, length: length)
            return regex.matches(in: string, options: [], range: range).map { MatchObject(string: string, match: $0) }
        }
        
        public func sub(_ repl: String, _ string: String, _ count: Int = 0) -> String {
            return subn(repl, string, count).0
        }
        
        public func subn(_ repl: String, _ string: String, _ count: Int = 0) -> (String, Int) {
            guard let regex = regex else {
                return (string, 0)
            }
            let range = NSRange(location: 0, length: string.utf16.count)
            let mutable = NSMutableString(string: string)
            let maxCount = count == 0 ? Int.max : (count > 0 ? count : 0)
            var n = 0
            var offset = 0
            regex.enumerateMatches(in: string, options: [], range: range) { result, _, stop in
                if maxCount <= n {
                    stop.pointee = true
                    return
                }
                if let result = result {
                    n += 1
                    let resultRange = NSRange(location: result.range.location + offset, length: result.range.length)
                    let lengthBeforeReplace = mutable.length
                    regex.replaceMatches(in: mutable, options: [], range: resultRange, withTemplate: repl)
                    offset += mutable.length - lengthBeforeReplace
                }
            }
            return (mutable as String, n)
        }
    }
    
    public final class MatchObject {
        /// String matched
        public let string: String
        
        /// Underlying NSTextCheckingResult
        public let match: NSTextCheckingResult
        
        init(string: String, match: NSTextCheckingResult) {
            self.string = string
            self.match = match
        }
        
        // function to expand string according to regular expression
        public func expand(_ template: String) -> String {
            guard let regex = match.regularExpression else {
                return ""
            }
            return regex.replacementString(for: match, in: string, offset: 0, template: template)
        }
        
        // function to group strings
        public func group(_ index: Int = 0) -> String? {
            guard let range = span(index), range.lowerBound < string.endIndex else {
                return nil
            }
            return String(string[range])
        }
        
        public func group(_ indexes: [Int]) -> [String?] {
            return indexes.map { group($0) }
        }
        
        public func groups(_ defaultValue: String) -> [String] {
            return (1..<match.numberOfRanges).map { group($0) ?? defaultValue }
        }
        
        public func groups() -> [String?] {
            return (1..<match.numberOfRanges).map { group($0) }
        }
        
        public func span(_ index: Int = 0) -> Range<String.Index>? {
            if index >= match.numberOfRanges {
                return nil
            }
            let nsrange = match.range(at: index)
            
            if nsrange.location == NSNotFound {
                return string.endIndex..<string.endIndex
            }
            let startIndex16 = string.utf16.index(string.startIndex, offsetBy: nsrange.location)
            let endIndex16 = string.utf16.index(startIndex16, offsetBy: nsrange.length)
            return (String.Index(startIndex16, within: string) ?? string.endIndex)..<(String.Index(endIndex16, within: string) ?? string.endIndex)
        }
    }
}


class ViewController : UIViewController, CLLocationManagerDelegate, SFSpeechRecognizerDelegate, MKMapViewDelegate {

    var steps = [MKRouteStep]()
    
    let speechSynth = AVSpeechSynthesizer()
    
    var stepCounter = 0
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Initialise location, buttons, and background colour
        mapView.removeOverlays(mapView.overlays)
        locationManager.delegate = self
        locationManager.requestWhenInUseAuthorization()
        locationManager.startUpdatingLocation()
        view.backgroundColor = UIColor(red: 0, green: 0.1843, blue: 0.5882, alpha: 1.0)
        textField.layer.cornerRadius = 5
        talkButton2.layer.cornerRadius = 10
        talkButton2.clipsToBounds = true
        locationManager.delegate = self as CLLocationManagerDelegate
        locationManager.requestWhenInUseAuthorization()
        talkButton2.isEnabled = false
        speechRecognizer?.delegate = self
        
        
        // Do any additional setup after loading the view, typically from a nib.
        SFSpeechRecognizer.requestAuthorization { (authStatus) in
            
            var isButtonEnabled = false
            
            switch authStatus {
            case .authorized:
                isButtonEnabled = true
                
            case .denied:
                isButtonEnabled = false
                print("Access Denied")
                
            case .restricted:
                isButtonEnabled = false
                print("Restricted")
                
            case .notDetermined:
                isButtonEnabled = false
                print("not yet authorized")
            }
            
            OperationQueue.main.addOperation() {
                self.talkButton2.isEnabled = isButtonEnabled
            }
        }
        
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    // function to draw route on map from users location to store location
    func ShowRoute(sourceCoordinate: CLLocationCoordinate2D, destiCoordinate: CLLocationCoordinate2D)
    {
        mapView.delegate = self
        
        let request = MKDirectionsRequest()
        request.source = MKMapItem(placemark: MKPlacemark(coordinate: sourceCoordinate, addressDictionary: nil))
        request.destination = MKMapItem(placemark: MKPlacemark(coordinate: destiCoordinate, addressDictionary: nil))
        request.requestsAlternateRoutes = true
        request.transportType = .automobile
        
        let directions = MKDirections(request: request)
        
        directions.calculate { [unowned self] response, error in
            guard let unwrappedResponse = response else { return }
            
            if (unwrappedResponse.routes.count > 0) {
                self.mapView.add(unwrappedResponse.routes[0].polyline, level: MKOverlayLevel.aboveRoads)
                self.mapView.setVisibleMapRect(unwrappedResponse.routes[0].polyline.boundingMapRect, animated: true)
                self.steps = unwrappedResponse.routes[0].steps
                for i in 0..<unwrappedResponse.routes[0].steps.count {
                    let step = unwrappedResponse.routes[0].steps[i]
                    print(step.instructions)
                    print(step.distance)
                    self.textField.text = "\(step.instructions)"
                    
                    let region = CLCircularRegion(center: step.polyline.coordinate, radius: 20, identifier: "\(i)")
                    
                    self.locationManager.startMonitoring(for: region)
                    let circle = MKCircle(center: region.center, radius: region.radius)
                    self.mapView.add(circle)
                    
                        let initial = "\(step.instructions)"
                        let speech = AVSpeechUtterance(string: initial)
                    speech.voice = AVSpeechSynthesisVoice(language: "en-au")
                        self.speechSynth.speak(speech)
                    
                   
                }
            }
        }
    }
    
    // function to render line on map
    func mapView(_ mapView: MKMapView, rendererFor overlay: MKOverlay) -> MKOverlayRenderer
    {
        if overlay is MKPolyline {
            let polylineRenderer = MKPolylineRenderer(overlay: overlay)
            polylineRenderer.strokeColor = UIColor.blue
            polylineRenderer.lineWidth = 5
            return polylineRenderer
        }
        return MKOverlayRenderer()
    }
    

    
    
    
    // outlet declaration for mapview
    @IBOutlet weak var mapView: MKMapView!
    
    let locationManager = CLLocationManager()
    // determine users location
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        let locations = locations[0]
        
        let center = locations.coordinate
        let span = MKCoordinateSpan(latitudeDelta: 0.05, longitudeDelta: 0.05)
        let region = MKCoordinateRegion(center: center, span: span)
        
        mapView.setRegion(region, animated: true)
        mapView.showsUserLocation = true
        
        
    }
    
    func locationManager(_ manager: CLLocationManager, didEnterRegion region: CLRegion) {
        print("ENTERED")
        stepCounter += 1
        if stepCounter < steps.count {
            let currentStep = steps[stepCounter]
            let message = "In \(currentStep.distance) meters, \(currentStep.instructions)"
            self.textField.text = message
            let speechUtterance = AVSpeechUtterance(string: message)
            speechSynth.speak(speechUtterance)
        } else {
            let message = "Arrived at destination"
            self.textField.text = message
            let speechUtterance = AVSpeechUtterance(string: message)
            speechSynth.speak(speechUtterance)
            stepCounter = 0
            locationManager.monitoredRegions.forEach({self.locationManager.stopMonitoring(for: $0)})
        }
    }
    
    // outlet declarations
    @IBOutlet weak var textField: UITextView!
    var dataObject: String = ""
    @IBOutlet weak var dataLabel: UILabel!
    
    @IBOutlet weak var talkButton2: UIButton!

    // This button, when pressed, starts recording the users voice, also refreshes map.
    @IBAction func talkButton(_ sender: AnyObject) {
        mapView.removeOverlays(mapView.overlays)
        textField.text = ""
        if audioEngine.isRunning {
            audioEngine.stop()
            recogntionRequest?.endAudio()
            talkButton2.isEnabled = false
            talkButton2.setTitle("Start Recording", for: .normal)
        } else {
            startRecording()
            talkButton2.setTitle("Stop Recording", for: .normal)
        }
    }
    
    @IBOutlet weak var infoBTN: UIButton!
    
    // This button, when pressed, displays help information via an alert for the user.
    @IBAction func infoButton(_ sender: AnyObject) {
        let alert = UIAlertController(title: "Help", message: "Tap the 'Speak' button to get started. \n Say things like: \n Take me to (store name) \n OR \n Call (store name) \n OR \n Ask for the information of a specific store \n OR \n Ask for the closest store to a specific location"
            
            
            , preferredStyle: UIAlertControllerStyle.alert)
        
        alert.addAction(UIAlertAction(title: "Got it", style: UIAlertActionStyle.default, handler: nil))
        
        self.present(alert, animated: true, completion: nil)
    }
    
    // This button, when pressed, displays copyright/legal information
    @IBAction func maxButton(_ sender: AnyObject) {
        let alert = UIAlertController(title: "About", message: "Copyright © Reece Max 2018. \n All rights reserved"
            
            
            , preferredStyle: UIAlertControllerStyle.alert)
        
        alert.addAction(UIAlertAction(title: "Got it", style: UIAlertActionStyle.default, handler: nil))
        
        self.present(alert, animated: true, completion: nil)
        
    }
    
    // Transcrption variables
    private let speechRecognizer = SFSpeechRecognizer(locale: Locale.init(identifier: "en-AU"))
    private var recogntionRequest: SFSpeechAudioBufferRecognitionRequest?
    private var recognitionTask: SFSpeechRecognitionTask?
    private let audioEngine = AVAudioEngine()
    
    // function that records what the user is saying
    func startRecording() {
        if recognitionTask != nil {
            recognitionTask?.cancel()
            recognitionTask = nil
        }
        
        let audioSession = AVAudioSession.sharedInstance()
        do {
            try audioSession.setCategory(AVAudioSessionCategoryRecord)
            try audioSession.setMode(AVAudioSessionModeMeasurement)
            try audioSession.setActive(true, with: .notifyOthersOnDeactivation)
        } catch
        {
            print("Session properties weren't set because of an error")
        }
        
        recogntionRequest = SFSpeechAudioBufferRecognitionRequest()
        
        let inputNode = audioEngine.inputNode
        
        
        //Launches the audio engine service
        func applicationDidFinishLaunching(aNotification: NSNotification) {
            audioEngine.prepare()
            do{
                try audioEngine.start()
            } catch
            {
                print("Audio Engine Error")
            }
        }
        
        
        // determines whether the user has given their permission to use voice recognition
        guard let recognitionRequest = recogntionRequest else {
            fatalError("unable to create SFSpeechAudioBufferRecognitionRequest")
        }
        
        recogntionRequest?.shouldReportPartialResults = true
        // determines what the user is saying and displays it to the text field
        recognitionTask = speechRecognizer!.recognitionTask(with: recogntionRequest!, resultHandler: { (result, error) in
            var isFinal = false
            if result != nil {
                self.textField.text = result?.bestTranscription.formattedString
                isFinal = (result?.isFinal)!
            }
            
            if error != nil || isFinal {
                self.audioEngine.stop()
                inputNode.removeTap(onBus: 0)
                
                self.recogntionRequest = nil
                self.recognitionTask = nil
                
                self.talkButton2.isEnabled  = true
            }
            // arrays containing store information
            // Name Address Phone Number Opening Hours Branch Manager Latitude Longitude
            var HeadOffice = [String]()
            HeadOffice.insert("Burwood Head Office", at: 0)
            HeadOffice.insert("118 Burwood Highway 3125", at: 1)
            HeadOffice.insert("92740222", at: 2)
            HeadOffice.insert("Mon - Fri 8.30AM to 5PM, Sat 9AM to 4PM", at: 3)
            HeadOffice.insert("Amanda Cogger", at: 4)
            HeadOffice.insert("-37.851020", at: 5)
            HeadOffice.insert("145.101755", at: 6)
            
            
            var BurwoodStore = [String]()
            BurwoodStore.insert("Reece Plumbing Burwood", at: 0)
            BurwoodStore.insert("2 Millicent Street Burwood 3125", at: 1)
            BurwoodStore.insert("92740910", at: 2)
            BurwoodStore.insert("Mon - Fri 7AM to 5PM, Sat 8AM to 12PM", at: 3)
            BurwoodStore.insert("Robert Mccahon", at: 4)
            BurwoodStore.insert("-37.851051", at: 5)
            BurwoodStore.insert("145.101894", at: 6)
            
            
            var BoxHillStore = [String]()
            BoxHillStore.insert("Reece Plumbing Box Hill", at: 0)
            BoxHillStore.insert("1127 Whitehorse Road Box Hill 3128", at: 1)
            BoxHillStore.insert("98989357", at: 2)
            BoxHillStore.insert("Mon - Fri 7AM to 5PM, Sat 8AM to 12PM", at: 3)
            BoxHillStore.insert("Brendon Walker", at: 4)
            BoxHillStore.insert("-37.819158", at: 5)
            BoxHillStore.insert("145.135194", at: 6)
            

            
            var CamberwellStore = [String]()
            CamberwellStore.insert("Reece Plumbing Camberwell", at: 0)
            CamberwellStore.insert("2 Cooloongatta Road Camberwell 3124", at: 1)
            CamberwellStore.insert("92452210", at: 2)
            CamberwellStore.insert("Mon - Fri 7AM to 5PM, Sat 8AM to 12PM", at: 3)
            CamberwellStore.insert("Brad Pinal", at: 4)
            CamberwellStore.insert("-37.834117", at: 5)
            CamberwellStore.insert("145.076315", at: 6)
        
    
            
            var KewStore = [String]()
            KewStore.insert("Reece Plumbing Kew", at: 0)
            KewStore.insert("360 High Street Kew 3101", at: 1)
            KewStore.insert("98551666", at: 2)
            KewStore.insert("Mon - Fri 7AM to 5PM, Sat 8AM to 12PM", at: 3)
            KewStore.insert("Tim Poynton", at: 4)
            KewStore.insert("-37.804702", at: 5)
            KewStore.insert("145.037038", at: 6)
            
            
            var ArmadaleStore = [String]()
            ArmadaleStore.insert("Reece Plumbing Armadale", at: 0)
            ArmadaleStore.insert("891-895 High Street Armadale VIC 3143", at: 1)
            ArmadaleStore.insert("85085040", at: 2)
            ArmadaleStore.insert("Mon - Fri 8.30AM to 5PM, Sat 9AM to 4PM", at: 3)
            ArmadaleStore.insert("Shane Crossley", at: 4)
            ArmadaleStore.insert("-37.854777", at: 5)
            ArmadaleStore.insert("145.016999", at: 6)
            
            var CaulfieldStore = [String]()
            CaulfieldStore.insert("Reece Plumbing Caufield", at: 0)
            CaulfieldStore.insert("865 Glen Huntly Road Caufield VIC 3143"
, at: 1)
            CaulfieldStore.insert("95239127", at: 2)
            CaulfieldStore.insert("Mon - Fri 7AM to 5PM, Sat 8AM to 5PM", at: 3)
            CaulfieldStore.insert("Kirk Annear", at: 4)
            CaulfieldStore.insert("-37.886891", at: 5)
            CaulfieldStore.insert("145.024448", at: 6)

            
            var OakleighSTHStore = [String]()
            OakleighSTHStore.insert("Reece Plumbing Oakleigh STH", at: 0)
            OakleighSTHStore.insert("Corner Carroll Road & Centre Road Oakleigh VIC 3166", at: 1)
            OakleighSTHStore.insert("95443689", at: 2)
            OakleighSTHStore.insert("Mon - Fri 7AM to 5PM, Sat 8AM to 12PM", at: 3)
            OakleighSTHStore.insert("Damien Healy", at: 4)
            OakleighSTHStore.insert("-37.926199", at: 5)
            OakleighSTHStore.insert("145.095465", at: 6)
            
            var ClaytonStore = [String]()
            ClaytonStore.insert("Reece Plumbing Clayton", at: 0)
            ClaytonStore.insert("2133 Princes Highway Clayton 3168", at: 1)
            ClaytonStore.insert("95447033", at: 2)
            ClaytonStore.insert("Mon - Fri 7AM to 5PM, Sat 8AM to 12PM", at: 3)
            ClaytonStore.insert("Steve Mccarthy", at: 4)
            ClaytonStore.insert("-37.922791", at: 5)
            ClaytonStore.insert("145.14158", at: 6)
            
            
            var RingwoodStore = [String]()
            RingwoodStore.insert("Reece Plumbing Ringwood", at: 0)
            RingwoodStore.insert("8 Pilgrim Court Ringwood 3134", at: 1)
            RingwoodStore.insert("88705691", at: 2)
            RingwoodStore.insert("Mon - Fri 7AM to 5PM, Sat 8AM to 12PM", at: 3)
            RingwoodStore.insert("Hayden Wright", at: 4)
            RingwoodStore.insert("-37.829501", at: 5)
            RingwoodStore.insert("145.21588", at: 6)
            
            // display test input to text field
            var test_input: String = "\(self.textField.text)"
            var test_output = ""
            
            // classifier: determine their intentions via what they have said
            var testing:[String: [[String:[String]]]] = [
                "intents":
                    [
                        ["intent":["Operation: location"],"utterances":["burwood","chadstone","blackburn","boxhill","dandenong"]],
                        ["intent":["Operation: call"],"utterances":["call","phone","ring","buzz","contact"]],
                        ["intent":["Operation: go"],"utterances":["go","navigate","direction","drive","take","lead"]],
                        ["intent":["Operation: info"], "utterances":
                            ["hours","trading","manager","branch","operating","open", "store"]],
                        ["intent":["Operation: closest"], "utterances":
                        ["nearest", "closest", "approximate", "proximity", "nearby",]]
                ]
            ]
            // set all test input to lowercase
            var to_lower_case = test_input.lowercased()
            var pre_mapper = re.sub("[+.!/_,$%^*)(+\"']+|[+——！，。？、~@#￥%……&*（）]+"," ",to_lower_case)
            //print("Pre Mapper : ",pre_mapper)
            //
            var mapper_out = [String]()
            // split mapper input
            var mapper_input = pre_mapper.split(separator: " ")
            
            //print("Mapper Input :",mapper_input)
            for word in mapper_input{
                if(word != ""){
                    let s = String(format: "%@ %d",word as CVarArg,1)
                    mapper_out.append(s)
                }
            }
            //print("Mapper Out : ",mapper_out)
            
            var current_word:String? = nil
            var current_count = 0
            var word:String? = nil
            
            var key_words = [String]()
            // for loop to go through words
            for line in mapper_out{
                let _line = line.trimmingCharacters(in:NSCharacterSet.whitespacesAndNewlines)
                var words = _line.split(separator: " ")
                let word = words[0]
                let count = Int(words[1])
                if (current_word == String(word)){
                    current_count += count!
                }
                else{
                    if (current_word != nil){
                        //            print ((current_word, current_count))
                        key_words.append(String(format: "%@", current_word!))
                    }
                    current_count = count!
                    current_word = String(word)
                }
            }
            // understand and act on what user is saying
            //print("Key Words: ",key_words)
            for key in testing.keys{
                for keys in testing[key]!{
                    for test in keys.keys{
                        if (test == "utterances"){
                            for tests in keys[test]!{
                                for keyword in key_words{
                                    if (keyword == tests.lowercased()){
                                        // Call X Store
                                        if(keys["intent"]![0] == "Operation: call"){
                                            let s = String(format:"Have %@ \n",keys["intent"]![0])
                                                                         print(s)
                                            test_output.append(contentsOf: s)
                                            // if user has asked to call said store, then call said store
                                            if (test_input).contains("Burwood")
                                            {
                                                let urlP : NSURL = NSURL(string: "tel://\(BurwoodStore[2])")!
                                                UIApplication.shared.canOpenURL(urlP as URL);  UIApplication.shared.open(urlP as URL)
                                            }
                                            else if (test_input).contains("head") // For head office
                                            {
                                                let urlP : NSURL = NSURL(string: "tel://\(HeadOffice[2])")!
                                                UIApplication.shared.canOpenURL(urlP as URL);  UIApplication.shared.open(urlP as URL)
                                            }
                                            else if (test_input).contains("box") // for box hill
                                            {
                                                let urlP : NSURL = NSURL(string: "tel://\(BoxHillStore[2])")!
                                                UIApplication.shared.canOpenURL(urlP as URL);  UIApplication.shared.open(urlP as URL)
                                            }
                                            else if (test_input).contains("Camberwell")
                                            {
                                                let urlP : NSURL = NSURL(string: "tel://\(CamberwellStore[2])")!
                                                UIApplication.shared.canOpenURL(urlP as URL);  UIApplication.shared.open(urlP as URL)
                                            }
                                            else if (test_input).contains("Kew") || (test_input).contains("Q")
                                            {
                                                let urlP : NSURL = NSURL(string: "tel://\(KewStore[2])")!
                                                UIApplication.shared.canOpenURL(urlP as URL);  UIApplication.shared.open(urlP as URL)
                                            }
                                            else if (test_input).contains("Armadale")
                                            {
                                                let urlP : NSURL = NSURL(string: "tel://\(ArmadaleStore[2])")!
                                                UIApplication.shared.canOpenURL(urlP as URL);  UIApplication.shared.open(urlP as URL)
                                            }
                                            else if (test_input).contains("Caulfield")
                                            {
                                                let urlP : NSURL = NSURL(string: "tel://\(CaulfieldStore[2])")!
                                                UIApplication.shared.canOpenURL(urlP as URL);  UIApplication.shared.open(urlP as URL)
                                            }
                                            else if (test_input).contains("Oakleigh") || (test_input).contains("Oakley")
                                            {
                                                let urlP : NSURL = NSURL(string: "tel://\(OakleighSTHStore[2])")!
                                                UIApplication.shared.canOpenURL(urlP as URL);  UIApplication.shared.open(urlP as URL)
                                            }
                                            else if (test_input).contains("Clayton")
                                            {
                                                let urlP : NSURL = NSURL(string: "tel://\(ClaytonStore[2])")!
                                                UIApplication.shared.canOpenURL(urlP as URL);  UIApplication.shared.open(urlP as URL)
                                            }
                                            else if (test_input).contains("Ringwood")
                                            {
                                                let urlP : NSURL = NSURL(string: "tel://\(RingwoodStore[2])")!
                                                UIApplication.shared.canOpenURL(urlP as URL);  UIApplication.shared.open(urlP as URL)
                                            }
                                        }
                                            
                                        // if the user has asked to be taken to a specific store, then take the user to that store
                                        else if (keys["intent"]![0]  == "Operation: go"){
                                            let s = String(format:"Have %@ \n",keys["intent"]![0])
                                                                            print(s)
                                            test_output.append(contentsOf: s)
                                            // NAVIGATION CODE HERE FROM CURRENT LOCATION TO STORE LOCATION
                                            // CALL X STORE
                                            
                                            let src = CLLocationCoordinate2DMake(self.mapView.userLocation.coordinate.latitude, self.mapView.userLocation.coordinate.longitude)
                                          
                                            
                                            if (test_input).contains("Burwood")
                                            {
                                                let des = CLLocationCoordinate2DMake(-37.851020, 145.101755)
                                                self.ShowRoute(sourceCoordinate: src, destiCoordinate: des)
                                            }
                                            else if (test_input).contains("head") // For head office
                                            {
                                                let des = CLLocationCoordinate2DMake(-37.851020, 145.101755)
                                                self.ShowRoute(sourceCoordinate: src, destiCoordinate: des)
                                            }
                                            else if (test_input).contains("Box") || (test_input).contains("box") // for box hill
                                            {
                                                let des = CLLocationCoordinate2DMake(-37.819158, 145.135194)
                                                self.ShowRoute(sourceCoordinate: src, destiCoordinate: des)
                                            }
                                            else if (test_input).contains("Camberwell")
                                            {
                                                let des = CLLocationCoordinate2DMake(-37.834117, 145.076315)
                                                self.ShowRoute(sourceCoordinate: src, destiCoordinate: des)
                                            }
                                            else if (test_input).contains("Kew") || (test_input).contains("Q")
                                            {
                                                let des = CLLocationCoordinate2DMake(-37.804702, 145.037038)
                                                self.ShowRoute(sourceCoordinate: src, destiCoordinate: des)
                                            }
                                            else if (test_input).contains("Armadale")
                                            {
                                                let des = CLLocationCoordinate2DMake(-37.854777, 145.016999)
                                                self.ShowRoute(sourceCoordinate: src, destiCoordinate: des)
                                            }
                                            else if (test_input).contains("Caulfield")
                                            {
                                                let des = CLLocationCoordinate2DMake(-37.886891, 145.024448)
                                                self.ShowRoute(sourceCoordinate: src, destiCoordinate: des)
                                            }
                                            else if (test_input).contains("Oakleigh") || (test_input).contains("Oakley")
                                            {
                                                let des = CLLocationCoordinate2DMake(-37.926199, 145.095465)
                                                self.ShowRoute(sourceCoordinate: src, destiCoordinate: des)
                                            }
                                            else if (test_input).contains("Clayton")
                                            {
                                                let des = CLLocationCoordinate2DMake(-37.922791, 145.14158)
                                                self.ShowRoute(sourceCoordinate: src, destiCoordinate: des)
                                            }
                                            else if (test_input).contains("Ringwood")
                                            {
                                                let des = CLLocationCoordinate2DMake(-37.829501, 145.21588)
                                                self.ShowRoute(sourceCoordinate: src, destiCoordinate: des)
                                            }
                                            
                                            
                                            
                                            
                                            
                                            
                                        }
                                        // if the user asks for the closest store at a specific location, then display that stores (distance from the location), if they wish to go there, take them there.
                                        else if (keys["intent"]![0] == "Operation: closest"){
                                            let s = String(format:"Have %@ \n",keys["intent"]![0], keyword)
                                            print(s)
                                            test_output.append(contentsOf: s)
                                            if (test_input).contains("Burwood")
                                            {
                                                let c1 = CLLocation(latitude: -37.851020, longitude: 145.101755)
                                                let c2 = CLLocation(latitude: -37.850140, longitude: 145.119034)
                                                let distance = c1.distance(from: c2)
                                                self.textField.text = "The closest store to Burwood is about \(String(format: "%2.f", distance)) meters away"
                                                if (test_input).contains("Go") || (test_input).contains("take")
                                                {
                                                    let src = CLLocationCoordinate2DMake(self.mapView.userLocation.coordinate.latitude, self.mapView.userLocation.coordinate.longitude)
                                                    let des = CLLocationCoordinate2DMake(-37.851020, 145.101755)
                                                    self.ShowRoute(sourceCoordinate: src, destiCoordinate: des)
                                                }
                                            }
                                            else if (test_input).contains("Box") || (test_input).contains("box") // for box hill
                                            {
                                                let c1 = CLLocation(latitude: -37.819158, longitude: 145.135194)
                                                let c2 = CLLocation(latitude: -37.821500, longitude: 145.126000)
                                                let distance = c1.distance(from: c2)
                                                self.textField.text = "The closest store to Box Hill is about \(String(format: "%2.f", distance)) meters away"
                                                if (test_input).contains("Go") || (test_input).contains("take")
                                                {
                                                    let src = CLLocationCoordinate2DMake(self.mapView.userLocation.coordinate.latitude, self.mapView.userLocation.coordinate.longitude)
                                                    let des = CLLocationCoordinate2DMake(-37.819158, 145.135194)
                                                    self.ShowRoute(sourceCoordinate: src, destiCoordinate: des)
                                                }
                                            }
                                            else if (test_input).contains("Camberwell")
                                            {
                                                
                                                let c1 = CLLocation(latitude: -37.834117, longitude: 145.076315)
                                                let c2 = CLLocation(latitude: -37.835000, longitude: 145.071000)
                                                let distance = c1.distance(from: c2)
                                                self.textField.text = "The closest store to Camberwell is about \(String(format: "%2.f", distance)) meters away"
                                                if (test_input).contains("Go") || (test_input).contains("take")
                                                {
                                                    let src = CLLocationCoordinate2DMake(self.mapView.userLocation.coordinate.latitude, self.mapView.userLocation.coordinate.longitude)
                                                    let des = CLLocationCoordinate2DMake(-37.834117, 145.076315)
                                                    self.ShowRoute(sourceCoordinate: src, destiCoordinate: des)
                                                }
                                            }
                                            else if (test_input).contains("Kew") || (test_input).contains("Q")
                                            {
                                                let c1 = CLLocation(latitude: -37.804702, longitude: 145.037038)
                                                let c2 = CLLocation(latitude: -37.805278, longitude: 145.035833)
                                                let distance = c1.distance(from: c2)
                                                self.textField.text = "The closest store to Kew is about \(String(format: "%2.f", distance)) meters away"
                                                if (test_input).contains("Go") || (test_input).contains("take")
                                                {
                                                    let src =  CLLocationCoordinate2DMake(self.mapView.userLocation.coordinate.latitude, self.mapView.userLocation.coordinate.longitude)
                                                    let des = CLLocationCoordinate2DMake(-37.804702, 145.037038)
                                                    self.ShowRoute(sourceCoordinate: src, destiCoordinate: des)
                                                }
                                            }
                                            else if (test_input).contains("Armadale")
                                            {
                                                let c1 = CLLocation(latitude: -37.854777, longitude: 145.016999)
                                                let c2 = CLLocation(latitude: -37.857000, longitude: 145.021000)
                                                let distance = c1.distance(from: c2)
                                                self.textField.text = "The closest store to Armadale is about \(String(format: "%2.f", distance)) meters away"
                                                if (test_input).contains("Go") || (test_input).contains("take")
                                                {
                                                    let src =  CLLocationCoordinate2DMake(self.mapView.userLocation.coordinate.latitude, self.mapView.userLocation.coordinate.longitude)
                                                    let des = CLLocationCoordinate2DMake(-37.854777, 145.016999)
                                                    self.ShowRoute(sourceCoordinate: src, destiCoordinate: des)
                                                }
                                            }
                                            else if (test_input).contains("Caulfield")
                                            {
                                                let c1 = CLLocation(latitude: -37.886891, longitude: 145.024448)
                                                let c2 = CLLocation(latitude: -37.884000, longitude: 145.026600)
                                                let distance = c1.distance(from: c2)
                                                self.textField.text = "The closest store to Caulfield is about \(String(format: "%2.f", distance)) meters away"
                                                if (test_input).contains("Go") || (test_input).contains("take")
                                                {
                                                    let src =  CLLocationCoordinate2DMake(self.mapView.userLocation.coordinate.latitude, self.mapView.userLocation.coordinate.longitude)
                                                    let des = CLLocationCoordinate2DMake(-37.886891, 145.024448)
                                                    self.ShowRoute(sourceCoordinate: src, destiCoordinate: des)
                                                }
                                                
                                            }
                                            else if (test_input).contains("Oakleigh") || (test_input).contains("Oakley")
                                            {
                                                let c1 = CLLocation(latitude: -37.926199, longitude: 145.095465)
                                                let c2 = CLLocation(latitude: -37.902070, longitude: 145.096207)
                                                let distance = c1.distance(from: c2)
                                                self.textField.text = "The closest store to Oakleigh is about \(String(format: "%2.f", distance)) meters away"
                                                if (test_input).contains("Go") || (test_input).contains("take")
                                                {
                                                    let src = CLLocationCoordinate2DMake(self.mapView.userLocation.coordinate.latitude, self.mapView.userLocation.coordinate.longitude)
                                                    let des = CLLocationCoordinate2DMake(-37.926199, 145.095465)
                                                    self.ShowRoute(sourceCoordinate: src, destiCoordinate: des)
                                                }
                                            }
                                            else if (test_input).contains("Clayton")
                                            {
                                                let c1 = CLLocation(latitude: -37.922791, longitude: 145.14158)
                                                let c2 = CLLocation(latitude: -37.915000, longitude: 145.13000)
                                                let distance = c1.distance(from: c2)
                                                self.textField.text = "The closest store to Clayton is about \(String(format: "%2.f", distance)) meters away"
                                                if (test_input).contains("Go") || (test_input).contains("take")
                                                {
                                                    let src = CLLocationCoordinate2DMake(self.mapView.userLocation.coordinate.latitude, self.mapView.userLocation.coordinate.longitude)
                                                    let des = CLLocationCoordinate2DMake(-37.922791, 145.14158)
                                                    self.ShowRoute(sourceCoordinate: src, destiCoordinate: des)
                                                }
                                            }
                                            else if (test_input).contains("Ringwood")
                                            {
                                                let c1 = CLLocation(latitude: 37.829501, longitude: 145.21588)
                                                let c2 = CLLocation(latitude: 37.811400, longitude: 145.230600)
                                                let distance = c1.distance(from: c2)
                                                self.textField.text = "The closest store to Ringwood is about \(String(format: "%2.f", distance)) meters away"
                                                if (test_input).contains("Go") || (test_input).contains("take")
                                                {
                                                    let src = CLLocationCoordinate2DMake(self.mapView.userLocation.coordinate.latitude, self.mapView.userLocation.coordinate.longitude)
                                                    let des = CLLocationCoordinate2DMake(-37.829501, 145.21588)
                                                    self.ShowRoute(sourceCoordinate: src, destiCoordinate: des)
                                                }
                                            }
                                            
                                            
                                        }
                                        // If a user asks for the information of a store, display it.
                                        else if (keys["intent"]![0] == "Operation: info"){
                                            var s = String(format:"Have %@ \n",keys["intent"]![0], keyword)
                                            print(s)
                                            test_output.append(contentsOf: s)
                                            /*
                                            if let url = URL(string: "https://www.reece.com.au/storefinder") {
                                                UIApplication.shared.open(url, options: [:])
                                            }
                                            */
                                            if (test_input).contains("Burwood")
                                            {
                                                
                                                print(BurwoodStore)
                                                self.textField.text = "\(BurwoodStore.joined(separator: "\n"))"
                                            }
                                            else if (test_input).contains("head") // For head office
                                            {
                                                print(HeadOffice)
                                                self.textField.text = "\(HeadOffice.joined(separator: "\n"))"
                                            }
                                            else if (test_input).contains("box") || (test_input).contains("Box") // for box hill
                                            {
                                                print(BoxHillStore)
                                                self.textField.text = "\(BoxHillStore.joined(separator: "\n"))"
                                            }
                                            else if (test_input).contains("Camberwell")
                                            {
                                                print(CamberwellStore)
                                                self.textField.text = "\(CamberwellStore.joined(separator: "\n"))"
                                            }
                                            else if (test_input).contains("Kew") || (test_input).contains("Q")
                                            {
                                                print(KewStore)
                                                self.textField.text = "\(KewStore.joined(separator: "\n"))"
                                            }
                                            else if (test_input).contains("Armadale")
                                            {
                                                print(ArmadaleStore)
                                                self.textField.text = "\(ArmadaleStore.joined(separator: "\n"))"
                                            }
                                            else if (test_input).contains("Caulfield")
                                            {
                                                print(CaulfieldStore)
                                                self.textField.text = "\(CaulfieldStore.joined(separator: "\n"))"
                                            }
                                            else if (test_input).contains("Oakleigh") || (test_input).contains("Oakley")
                                            {
                                                print(OakleighSTHStore)
                                                self.textField.text = "\(OakleighSTHStore.joined(separator: "\n"))"
                                            }
                                            else if (test_input).contains("Clayton")
                                            {
                                                print(ClaytonStore)
                                                self.textField.text = "\(ClaytonStore.joined(separator: "\n"))"
                                            }
                                            else if (test_input).contains("Ringwood")
                                            {
                                                print(RingwoodStore)
                                                self.textField.text = "\(RingwoodStore.joined(separator: "\n"))"
                                            }
                                        }
                                        else if (keys["intent"]![0] == "Operation: closest"){
                                            let s = String(format:"Have %@ \n",keys["intent"]![0], keyword)
                                            print(s)
                                            test_output.append(contentsOf: s)
                                            // find closest store to me
                                        }
                                            
                                            
                                            
                                        else {
                                            print("Error!")// #useless. This line doesn't make any sence.
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }

        })

        // start audio node and begin recording
        let recordingFormat = inputNode.outputFormat(forBus: 0)
        inputNode.installTap(onBus: 0, bufferSize: 1024, format: recordingFormat) { (buffer, when) in
            self.recogntionRequest?.append(buffer)
        }
        // prepare audio engine
        audioEngine.prepare()
        
        // try start audio engine, if it cant, tell the user what went wrong.
        do {
            try audioEngine.start()
        } catch {
            print("Audio Engine cant start")
        }
    }
    
    // check if the button has been pressed
    func speechRecognizer(_ speechRecognizer: SFSpeechRecognizer, availabilityDidChange available: Bool) {
        if available {
            talkButton2.isEnabled = true
        } else {
            talkButton2.isEnabled = false
        }
    }
}

