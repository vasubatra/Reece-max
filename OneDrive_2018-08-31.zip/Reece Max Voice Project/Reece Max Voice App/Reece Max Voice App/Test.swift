//
//  Test.swift
//  Reece Max Voice App
//
//  Created by Omar Faraj on 25/6/18.
//  Copyright © 2018 deakin. All rights reserved.
//

import UIKit
import Foundation

class Test: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

   
    public class re {
        public static func compile(_ pattern: String, flags: RegexObject.Flag = []) -> RegexObject  {
            return RegexObject(pattern: pattern, flags: flags)
        }
        
        public static func search(_ pattern: String, _ string: String, flags: RegexObject.Flag = []) -> MatchObject? {
            return re.compile(pattern, flags: flags).search(string)
        }
        
        public static func match(_ pattern: String, _ string: String, flags: RegexObject.Flag = []) -> MatchObject? {
            return re.compile(pattern, flags: flags).match(string)
        }
        
        public static func split(_ pattern: String, _ string: String, _ maxsplit: Int = 0, flags: RegexObject.Flag = []) -> [String?] {
            return re.compile(pattern, flags: flags).split(string, maxsplit)
        }
        
        public static func findall(_ pattern: String, _ string: String, flags: RegexObject.Flag = []) -> [String] {
            return re.compile(pattern, flags: flags).findall(string)
        }
        
        public static func finditer(_ pattern: String, _ string: String, flags: RegexObject.Flag = []) -> [MatchObject] {
            return re.compile(pattern, flags: flags).finditer(string)
        }
        
        public static func sub(_ pattern: String, _ repl: String, _ string: String, _ count: Int = 0, flags: RegexObject.Flag = []) -> String {
            return re.compile(pattern, flags: flags).sub(repl, string, count)
        }
        
        public static func subn(_ pattern: String, _ repl: String, _ string: String, _ count: Int = 0, flags: RegexObject.Flag = []) -> (String, Int) {
            return re.compile(pattern, flags: flags).subn(repl, string, count)
        }
        
        public class RegexObject {
            /// Typealias for NSRegularExpressionOptions
            public typealias Flag = NSRegularExpression.Options
            
            /// Whether this object is valid or not
            public var isValid: Bool {
                return regex != nil
            }
            
            /// Pattern used to construct this RegexObject
            public let pattern: String
            
            private let regex: NSRegularExpression?
            
            /// Underlying NSRegularExpression Object
            public var nsRegex: NSRegularExpression? {
                return regex
            }
            
            /// NSRegularExpressionOptions used to contructor this RegexObject
            public var flags: Flag {
                return regex?.options ?? []
            }
            
            /// Number of capturing groups
            public var groups: Int {
                return regex?.numberOfCaptureGroups ?? 0
            }
            
            public required init(pattern: String, flags: Flag = [])  {
                self.pattern = pattern
                do {
                    self.regex = try NSRegularExpression(pattern: pattern, options: flags)
                } catch let error as NSError {
                    self.regex = nil
                    debugPrint(error)
                }
            }
            public func search(_ string: String, _ pos: Int = 0, _ endpos: Int? = nil, options: NSRegularExpression.MatchingOptions = []) -> MatchObject? {
                guard let regex = regex else {
                    return nil
                }
                let start = pos > 0 ?pos :0
                let end = endpos ?? string.utf16.count
                let length = max(0, end - start)
                let range = NSRange(location: start, length: length)
                if let match = regex.firstMatch(in: string, options: options, range: range) {
                    return MatchObject(string: string, match: match)
                }
                return nil
            }
            public func match(_ string: String, _ pos: Int = 0, _ endpos: Int? = nil) -> MatchObject? {
                return search(string, pos, endpos, options: [.anchored])
            }
            
            public func split(_ string: String, _ maxsplit: Int = 0) -> [String?] {
                guard let regex = regex else {
                    return []
                }
                var splitsLeft = maxsplit == 0 ? Int.max : (maxsplit < 0 ? 0 : maxsplit)
                let range = NSRange(location: 0, length: string.utf16.count)
                var results = [String?]()
                var start = string.startIndex
                var end = string.startIndex
                regex.enumerateMatches(in: string, options: [], range: range) { result, _, stop in
                    if splitsLeft <= 0 {
                        stop.pointee = true
                        return
                    }
                    
                    guard let result = result, result.range.length > 0 else {
                        return
                    }
                    
                    end = string.characters.index(string.startIndex, offsetBy: result.range.location)
                    results.append(String(string[start..<end]))
                    if regex.numberOfCaptureGroups > 0 {
                        results += MatchObject(string: string, match: result).groups()
                    }
                    splitsLeft -= 1
                    start = string.index(end, offsetBy: result.range.length)
                }
                if start <= string.endIndex {
                    results.append(String(string[start..<string.endIndex]))
                }
                return results
            }
            
            public func findall(_ string: String, _ pos: Int = 0, _ endpos: Int? = nil) -> [String] {
                return finditer(string, pos, endpos).map { $0.group()! }
            }
            
            public func finditer(_ string: String, _ pos: Int = 0, _ endpos: Int? = nil) -> [MatchObject] {
                guard let regex = regex else {
                    return []
                }
                let start = pos > 0 ?pos :0
                let end = endpos ?? string.utf16.count
                let length = max(0, end - start)
                let range = NSRange(location: start, length: length)
                return regex.matches(in: string, options: [], range: range).map { MatchObject(string: string, match: $0) }
            }
            
            public func sub(_ repl: String, _ string: String, _ count: Int = 0) -> String {
                return subn(repl, string, count).0
            }
            
            public func subn(_ repl: String, _ string: String, _ count: Int = 0) -> (String, Int) {
                guard let regex = regex else {
                    return (string, 0)
                }
                let range = NSRange(location: 0, length: string.utf16.count)
                let mutable = NSMutableString(string: string)
                let maxCount = count == 0 ? Int.max : (count > 0 ? count : 0)
                var n = 0
                var offset = 0
                regex.enumerateMatches(in: string, options: [], range: range) { result, _, stop in
                    if maxCount <= n {
                        stop.pointee = true
                        return
                    }
                    if let result = result {
                        n += 1
                        let resultRange = NSRange(location: result.range.location + offset, length: result.range.length)
                        let lengthBeforeReplace = mutable.length
                        regex.replaceMatches(in: mutable, options: [], range: resultRange, withTemplate: repl)
                        offset += mutable.length - lengthBeforeReplace
                    }
                }
                return (mutable as String, n)
            }
        }
        
        public final class MatchObject {
            /// String matched
            public let string: String
            
            /// Underlying NSTextCheckingResult
            public let match: NSTextCheckingResult
            
            init(string: String, match: NSTextCheckingResult) {
                self.string = string
                self.match = match
            }
            
            public func expand(_ template: String) -> String {
                guard let regex = match.regularExpression else {
                    return ""
                }
                return regex.replacementString(for: match, in: string, offset: 0, template: template)
            }
            
            public func group(_ index: Int = 0) -> String? {
                guard let range = span(index), range.lowerBound < string.endIndex else {
                    return nil
                }
                return String(string[range])
            }
            
            public func group(_ indexes: [Int]) -> [String?] {
                return indexes.map { group($0) }
            }
            
            public func groups(_ defaultValue: String) -> [String] {
                return (1..<match.numberOfRanges).map { group($0) ?? defaultValue }
            }
            
            public func groups() -> [String?] {
                return (1..<match.numberOfRanges).map { group($0) }
            }
            
            public func span(_ index: Int = 0) -> Range<String.Index>? {
                if index >= match.numberOfRanges {
                    return nil
                }
                let nsrange = match.range(at: index)
                
                if nsrange.location == NSNotFound {
                    return string.endIndex..<string.endIndex
                }
                let startIndex16 = string.utf16.index(string.startIndex, offsetBy: nsrange.location)
                let endIndex16 = string.utf16.index(startIndex16, offsetBy: nsrange.length)
                return (String.Index(startIndex16, within: string) ?? string.endIndex)..<(String.Index(endIndex16, within: string) ?? string.endIndex)
            }
        }
    }

}
